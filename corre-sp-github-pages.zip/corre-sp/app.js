const state={mode:'day',events:[]};
const $=id=>document.getElementById(id);
const monthNames=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
monthNames.forEach((m,i)=>$('month').add(new Option(m,String(i+1).padStart(2,'0'))));
$('month').value='11';
document.querySelectorAll('.mode').forEach(btn=>btn.addEventListener('click',()=>{
  state.mode=btn.dataset.mode;
  document.querySelectorAll('.mode').forEach(b=>b.classList.toggle('active',b===btn));
  $('dayFields').classList.toggle('hidden',state.mode!=='day');
  $('rangeFields').classList.toggle('hidden',state.mode!=='range');
  $('monthFields').classList.toggle('hidden',state.mode!=='month');
  render();
}));
function dateRange(){
 if(state.mode==='day'){let d=$('day').value;return [d,d]}
 if(state.mode==='range'){return [$('start').value,$('end').value]}
 const y=$('year').value,m=$('month').value;
 return [`${y}-${m}-01`,`${y}-${m}-${new Date(Number(y),Number(m),0).getDate()}`];
}
function fmtDate(s){if(!s)return 'Data a confirmar';return new Date(s+'T12:00:00').toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'}).replace('.','')}
function fmtPrice(p){return p==null?'A confirmar':p===0?'Grátis':p.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}
function distanceMatch(e,v){if(!v)return true;if(v==='unknown')return !e.distancias||!e.distancias.length;let n=Number(v);return (e.distancias||[]).some(d=>n===21?d>=20&&d<22:n===42?d>=40:d===n)}
function render(){
 const [from,to]=dateRange(),maxPrice=$('price').value===''?null:Number($('price').value),dist=$('distance').value,query=$('searchText').value.trim().toLowerCase();
 let rows=state.events.filter(e=>e.data>=from&&e.data<=to&&distanceMatch(e,dist));
 if(maxPrice!==null)rows=rows.filter(e=>e.preco!==null&&e.preco<=maxPrice);
 if(query)rows=rows.filter(e=>[e.nome,e.local,e.endereco,e.organizador].join(' ').toLowerCase().includes(query));
 const sort=$('sort').value;
 rows.sort((a,b)=>sort==='name'?a.nome.localeCompare(b.nome):sort==='price'?((a.preco??Infinity)-(b.preco??Infinity)):a.data.localeCompare(b.data));
 $('count').textContent=`${rows.length} evento${rows.length===1?'':'s'}`;
 $('results').innerHTML=rows.map(card).join('');
 $('empty').classList.toggle('hidden',rows.length>0);
}
function card(e){
 const d=new Date(e.data+'T12:00:00');
 const dist=(e.distancias||[]).length?e.distancias.map(x=>`<span class="pill">${x>=20&&x<22?'21 km':x>=40?'42 km':x+' km'}</span>`).join(''):'<span class="pill">Distância a confirmar</span>';
 const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 return `<article class="race-card"><div class="race-top"><div><h3>${safe(e.nome)}</h3><div class="organizer">${safe(e.organizador||'Organizador a confirmar')}</div></div><div class="race-date"><strong>${d.getDate()}</strong>${d.toLocaleDateString('pt-BR',{month:'short'}).replace('.','')}</div></div><div><span class="status">CONFIRME OS DETALHES</span></div><div class="detail"><span class="ico">◷</span><div><strong>Largada:</strong> ${safe(e.horario||'A confirmar')}</div></div><div class="detail"><span class="ico">⌖</span><div><strong>Local:</strong> ${safe(e.local||'A confirmar')}<br>${safe(e.endereco||'Endereço exato a confirmar')}</div></div><div class="detail"><span class="ico">R$</span><div><strong>Inscrição:</strong> ${fmtPrice(e.preco)}</div></div><div class="detail"><span class="ico">◉</span><div><strong>Retirada do kit:</strong> ${safe(e.kit||'A confirmar no regulamento')}</div></div><div class="pills">${dist}</div><p class="small-note">${safe(e.status||'Confira os detalhes diretamente com o organizador.')}</p><div class="card-links"><a href="${safe(e.oficial)}" target="_blank" rel="noopener">Página / organizador ↗</a><a href="${safe(e.fonte)}" target="_blank" rel="noopener">Fonte do calendário ↗</a><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e.endereco||e.local||'São Paulo SP')}" target="_blank" rel="noopener">Ver mapa ↗</a></div></article>`;
}
['day','start','end','month','year','distance','price','searchText','sort'].forEach(id=>$(id).addEventListener('input',render));
$('weekBtn').addEventListener('click',()=>{
 const start=$('start').value||new Date().toISOString().slice(0,10);
 const d=new Date(start+'T12:00:00');const weekday=(d.getDay()+6)%7;
 d.setDate(d.getDate()-weekday);const monday=d.toISOString().slice(0,10);
 d.setDate(d.getDate()+6);const sunday=d.toISOString().slice(0,10);
 $('start').value=monday;$('end').value=sunday;render();
});
$('clearBtn').addEventListener('click',()=>{
 $('distance').value='';$('price').value='';$('searchText').value='';$('sort').value='date';render();
});
fetch('./corridas.json').then(r=>{if(!r.ok)throw new Error('Não foi possível carregar corridas.json');return r.json()}).then(data=>{state.events=data;render()}).catch(err=>{$('count').textContent='Erro ao carregar base';$('results').innerHTML='<p class="empty">Não foi possível carregar corridas.json. Confira se o arquivo está na mesma pasta de index.html.</p>';console.error(err)});
