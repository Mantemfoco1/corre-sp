# Corre SP — Buscador pessoal de corridas

Site estático para GitHub Pages com pesquisa por:
- dia específico;
- intervalo de datas;
- semana inteira (segunda a domingo);
- mês e ano;
- distância, preço máximo e texto livre.

## Arquivos
- `index.html`: estrutura do site.
- `style.css`: visual responsivo.
- `app.js`: filtros, datas e renderização.
- `corridas.json`: base de eventos que pode ser editada.

## Publicar no GitHub Pages
1. Entre no GitHub e crie um repositório público, por exemplo `corre-sp`.
2. Clique em **Add file > Upload files** e envie os quatro arquivos.
3. Clique em **Commit changes**.
4. Abra **Settings > Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**.
6. Escolha a branch `main` e a pasta `/(root)`, depois clique em **Save**.
7. Aguarde o GitHub publicar e abra o endereço mostrado na própria página Settings > Pages.

A documentação oficial: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages

## Atualizar corridas
Edite `corridas.json` e faça commit. Cada evento segue esta estrutura:
```json
{
  "id": "identificador-unico",
  "nome": "Nome da prova",
  "data": "2026-11-15",
  "local": "Parque / região",
  "endereco": "Endereço completo",
  "horario": "06:30",
  "distancias": [5, 10],
  "preco": 89.9,
  "kit": "Local e data de retirada",
  "organizador": "Organizador",
  "oficial": "https://link-oficial-do-evento.example/",
  "fonte": "https://fonte-verificavel.example/",
  "status": "Informação confirmada em DD/MM/AAAA."
}
```
Use `null` para preço ou horário não confirmado, e `[]` para distância ainda não confirmada. Nunca preencha com estimativas. Para links oficiais, prefira página específica do evento ou do organizador; os links genéricos na base inicial servem como ponto de partida e devem ser substituídos por páginas específicas assim que confirmadas.

## Importante sobre pesquisa automática
GitHub Pages hospeda HTML/CSS/JavaScript estáticos. Este projeto não rastreia sites externos nem atualiza dados sozinho. Ele pesquisa os eventos que estão em `corridas.json`. Para busca profunda automática em sites externos, seria necessário um backend/API ou fluxo externo de atualização, respeitando termos de uso e limites dos sites. Esta versão indica campos ausentes como “A confirmar” e inclui links para verificar informações.

## Fontes iniciais
- Prefeitura de São Paulo: https://prefeitura.sp.gov.br/w/servico/corridas-de-rua
- Calendário VamuCorrer: https://vamucorrer.com.br/corridas/sao-paulo/sao-paulo/por-mes/novembro/2026
- Ticket Sports: https://stag.ticketsports.com.br/Calendario/Todos-os-organizadores/Corrida-de-rua/SP/S%C3%A3o%20paulo/0%2C00/0%2C00/false/
